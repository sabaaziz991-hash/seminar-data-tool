"""Manual verification of flagged media terms in the judgments.

The decisions are stored by a stable key (case_id, position in body text, term) in
03_ניתוח/media_manual_decisions.csv, so re-running text_measures.py never loses them.

Inclusion rule: the judgment refers to mass media (press, TV/radio news, news websites, journalists,
media interviews, publications in newspapers) in connection with the case - the offence, the
investigation, the defendant, witnesses, victims or the proceedings. Excluded: non-media senses
(telecommunication, interpersonal communication, clinical or police "interviews", publication of
laws/rulings/academic work, gag orders, citation formulas), TV/radio as objects, hypothetical or
general statements not tied to the case, social-media posts by the defendant, psychiatric content.
Categories: A = the case/participants as subject of media coverage or interviews;
            B = media as a source of information within the facts/evidence;
            C = claims about media influence/pressure on the proceedings.
Rows excluded by the automatic rules were spot-checked; genuine mentions were overridden to "include".
"""
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    c = pd.read_csv(ROOT / "02_נתונים" / "media_mention_candidates.csv")
    reviewed = c[c.auto_excluded == 0]
    missing = reviewed[reviewed.manual_decision.isna()]
    if len(missing):
        raise SystemExit(f"{len(missing)} flagged rows still need a manual decision")
    inc = c[c.manual_decision == "include"]
    print("flagged:", len(c), "| auto-excluded:", int(c.auto_excluded.sum()), "| manually reviewed:", len(reviewed))
    print("included mentions:", len(inc), "| cases:", inc.case_id.nunique(), "| by category:", inc.manual_reason.value_counts().to_dict())
    print("included mentions inside the reasoning section:", int(inc.in_reasoning.sum()), "| cases:", inc[inc.in_reasoning == 1].case_id.nunique())
