"""Figures for the paper (PNG, 300 dpi). Hebrew text is reordered with python-bidi for matplotlib."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402
from bidi.algorithm import get_display  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analysis_core as ac  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "03_ניתוח" / "figures"
OUT.mkdir(exist_ok=True)

INK, INK2, GRID, BAR, SURFACE = "#0b0b0b", "#52514e", "#e4e3df", "#2a78d6", "#ffffff"
plt.rcParams.update({"font.family": "Arial", "font.size": 11, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "figure.facecolor": SURFACE, "axes.facecolor": SURFACE})


def h(text: str) -> str:
    return get_display(text)


def load() -> pd.DataFrame:
    d = pd.read_csv(ROOT / "02_נתונים" / "study_dataset_final.csv")
    return d[d.merits_appeal == 1]


def bar_chart(groups, path: Path, xlabel: str, width_in: float) -> None:
    fig, ax = plt.subplots(figsize=(width_in, 3.6), dpi=300)
    xs = range(len(groups))
    rates = [g["rate"] * 100 for g in groups]
    lo = [g["rate"] * 100 - g["ci"][0] * 100 for g in groups]
    hi = [g["ci"][1] * 100 - g["rate"] * 100 for g in groups]
    ax.bar(xs, rates, width=0.52, color=BAR, zorder=2)
    ax.errorbar(xs, rates, yerr=[lo, hi], fmt="none", ecolor=INK2, elinewidth=1.2, capsize=4, zorder=3)
    for x, g in zip(xs, groups):
        ax.text(x, g["ci"][1] * 100 + 1.5, f"{g['rate']*100:.1f}%", ha="center", va="bottom", color=INK, fontsize=10)
    ax.set_xticks(list(xs), [h(g["label"]) + f"\n{h('n')}={g['n']}" for g in groups])
    ax.set_ylabel(h("שיעור התערבות (%)"))
    ax.set_xlabel(h(xlabel))
    ax.set_ylim(0, max(g["ci"][1] for g in groups) * 100 + 10)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8, zorder=0)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    fig.tight_layout()
    fig.savefig(path, facecolor=SURFACE)
    plt.close(fig)


def fig_rates(d: pd.DataFrame) -> None:
    r = ac.two_by_two(d, "media_any", "intervention")
    groups = [
        {"label": "ללא בולטות", "n": r["n_unexposed"], "rate": r["rate_unexposed"], "ci": r["rate_unexposed_ci"]},
        {"label": "עם בולטות", "n": r["n_exposed"], "rate": r["rate_exposed"], "ci": r["rate_exposed_ci"]},
    ]
    bar_chart(groups, OUT / "fig2_intervention_by_salience.png", "בולטות תקשורתית מוקדמת", 4.2)


def fig_dose(d: pd.DataFrame) -> None:
    dd = d.rename(columns={"media_count": "district_plus_appeal_article_count", "intervention": "court_intervention"})
    res = ac.dose_response(dd)
    names = {"0": "אין פרסומים", "1": "פרסום אחד", "2-4": "2-4 פרסומים", "5+": "5 ומעלה"}
    groups = [{"label": names[b["group"]], "n": b["n"], "rate": b["rate"], "ci": b["ci"]} for b in res["buckets"]]
    bar_chart(groups, OUT / "fig3_intervention_by_items.png", "מספר הפרסומים שקדמו להכרעה", 5.6)


def fig_flow() -> None:
    fc = json.loads((ROOT / "03_ניתוח" / "flow_counts.json").read_text(encoding="utf-8"))
    main = [
        (f"{fc['hf_documents']:,} מסמכים במאגר בית המשפט העליון", "(Hugging Face)"),
        (f"{fc['criminal_appeal_cases_with_final_judgment_2010_2020']:,} ערעורים פליליים (ע\"פ)", "עם פסק דין סופי, 2010-2020"),
        (f"{fc['homicide_cases']:,} ערעורים בעבירות המתה", "(רצח והמתה אחרת)"),
        (f"{fc['homicide_defendant_appeals']:,} ערעורים שהגיש הנאשם", ""),
        ("497 תיקים במאגר המחקר", "לאחר אימות ידני"),
        ("478 ערעורים על הכרעת דין או גזר דין", "מדגם הניתוח"),
    ]
    side = {2: f"{fc['criminal_appeal_cases_with_final_judgment_2010_2020'] - fc['homicide_cases']:,} בעבירות אחרות",
            3: f"{fc['homicide_cases'] - fc['homicide_defendant_appeals']} ערעורי מדינה",
            4: f"{fc['homicide_defendant_appeals_anonymous_excluded']} בשם חסוי (\"פלוני\")\n5 שלא נכללו; 1 נוסף באימות",
            5: "19 הליכים שאינם ערעור לגופו\n(פסלות שופט 11, הסגרה 3, אחרים 5)"}
    fig, ax = plt.subplots(figsize=(6.6, 7.4), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, len(main) * 1.25 + 0.2)
    ax.axis("off")
    y0 = len(main) * 1.25 - 0.5
    for i, (t1, t2) in enumerate(main):
        y = y0 - i * 1.25
        ax.add_patch(plt.Rectangle((3.6, y - 0.42), 6.1, 0.84, facecolor="#eef4fc" if i == len(main) - 1 else SURFACE,
                                   edgecolor=BAR if i == len(main) - 1 else INK2, linewidth=1.2))
        ax.text(6.65, y + (0.13 if t2 else 0), h(t1), ha="center", va="center", fontsize=10.5, color=INK,
                fontweight="bold" if i == len(main) - 1 else "normal")
        if t2:
            ax.text(6.65, y - 0.2, h(t2), ha="center", va="center", fontsize=9, color=INK2)
        if i < len(main) - 1:
            ax.annotate("", xy=(6.65, y - 0.83), xytext=(6.65, y - 0.42), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=1.1))
        if i + 1 in side:
            ys = y - 0.625
            ax.annotate("", xy=(3.45, ys), xytext=(6.65, ys), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=0.9))
            ax.add_patch(plt.Rectangle((0.05, ys - 0.38), 3.35, 0.76, facecolor="#f6f6f4", edgecolor=GRID, linewidth=1))
            ax.text(1.72, ys, "\n".join(h(line) for line in ("הוחרגו: " + side[i + 1]).split("\n")), ha="center",
                    va="center", fontsize=8.5, color=INK2)
    fig.tight_layout()
    fig.savefig(OUT / "fig1_flow.png", facecolor=SURFACE)
    plt.close(fig)


if __name__ == "__main__":
    data = load()
    fig_flow()
    fig_rates(data)
    fig_dose(data)
    print("saved:", sorted(p.name for p in OUT.glob("*.png")))
