"""Reconstruct the case-selection flow (PRISMA-style counts) from the Hugging Face dataset.

Uses the classification functions of the original pipeline (appeals_media_study.py) so the
counts follow the same rules that produced the study corpus.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from pathlib import Path

import pandas as pd
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[1]
# folder of the original collection pipeline (appeals_media_study.py); set APPEALS_PIPELINE_DIR to point to it.
# The SeminarDataTool reproduces these filtering steps on its own, without the pipeline.
PIPELINE = Path(os.environ.get("APPEALS_PIPELINE_DIR", ROOT.parent / "seminar2ענבל" / "audit_scripts"))
sys.path.insert(0, str(PIPELINE))
from appeals_media_study import classify_appellant_type, classify_offense, is_anonymous_name  # noqa: E402

HF = ROOT / "02_נתונים" / "hf_raw" / "cases_all.parquet"
STUDY = ROOT / "02_נתונים" / "FINAL_STUDY_DATA_2010_2020_PRIMO_MANUAL_REVIEW_2026-05-27_113917" / "01_final_dataset" / "final_analysis_variables_2010_2020_primo_manual_review.csv"
OUT = ROOT / "03_ניתוח" / "flow_counts.json"


def study_id(case_id: int) -> str:
    return "HUGGINGFACE-" + hashlib.sha1(str(case_id).encode()).hexdigest()[:12]


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    cols = ["CaseId", "CaseDesc", "CaseName", "Type", "Technical", "VerdictDt"]
    meta = pq.read_table(HF, columns=cols).to_pandas()
    flow: dict[str, int] = {"hf_documents": len(meta), "hf_cases": meta.CaseId.nunique()}

    meta["vd"] = pd.to_datetime(meta.VerdictDt).dt.tz_localize(None)
    fa = meta[meta.CaseDesc.fillna("").str.match(r'^\s*ע"פ\s')]
    flow["criminal_appeal_cases_any_year"] = fa.CaseId.nunique()

    final = fa[(fa.Type == "פסק-דין") & (~fa.Technical.fillna(False))]
    final = final[(final.vd >= "2010-01-01") & (final.vd <= "2020-12-31")]
    # one final judgment per case: the latest non-technical judgment in the window
    final = final.sort_values("vd").groupby("CaseId").tail(1)
    flow["criminal_appeal_cases_with_final_judgment_2010_2020"] = len(final)

    ids = set(final.CaseId)
    txt = pq.read_table(HF, columns=["CaseId", "Type", "Technical", "VerdictDt", "text"],
                        filters=[("CaseId", "in", list(ids))]).to_pandas()
    txt = txt[(txt.Type == "פסק-דין") & (~txt.Technical.fillna(False)) & txt.text.notna()]
    txt["vd"] = pd.to_datetime(txt.VerdictDt).dt.tz_localize(None)
    txt = txt.sort_values("vd").groupby("CaseId").tail(1).set_index("CaseId")

    rows = []
    for _, r in final.iterrows():
        text = txt.text.get(r.CaseId, "") or ""
        off = classify_offense(text)
        rows.append({
            "CaseId": r.CaseId,
            "study_case_id": study_id(r.CaseId),
            "case_number": r.CaseDesc,
            "case_name": r.CaseName,
            "murder_or_homicide": int(off.get("murder_or_homicide") or 0),
            "appellant_type": classify_appellant_type(r.CaseName or "", text[:4000]),
            "anonymous": bool(is_anonymous_name(r.CaseName or "")),
        })
    df = pd.DataFrame(rows)
    hom = df[df.murder_or_homicide == 1]
    flow["homicide_cases"] = len(hom)
    defe = hom[hom.appellant_type == "defendant"]
    flow["homicide_defendant_appeals"] = len(defe)
    flow["homicide_defendant_appeals_anonymous_excluded"] = int(defe.anonymous.sum())
    named = defe[~defe.anonymous]
    flow["homicide_defendant_appeals_named"] = len(named)

    study = pd.read_csv(STUDY)
    flow["study_corpus"] = len(study)
    flow["study_corpus_found_in_reconstruction"] = int(study.case_id.isin(set(named.study_case_id)).sum())
    flow["reconstruction_not_in_study"] = int((~named.study_case_id.isin(set(study.case_id))).sum())
    df.to_csv(ROOT / "03_ניתוח" / "flow_reconstruction_cases.csv", index=False, encoding="utf-8-sig")
    OUT.write_text(json.dumps(flow, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(flow, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
