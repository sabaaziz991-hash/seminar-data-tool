"""Build the final analysis file (one row per case, no party names) used by SPSS and by the tool."""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analysis_core import add_scope_flags, salience_bucket  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "02_נתונים"
SRC = DATA / "FINAL_STUDY_DATA_2010_2020_PRIMO_MANUAL_REVIEW_2026-05-27_113917" / "01_final_dataset" / "final_analysis_variables_2010_2020_primo_manual_review.csv"
OUT = DATA / "study_dataset_final.csv"

RELIEF_CODE = {"none": 0, "sentence_relief_only": 1, "conviction_modified_lesser_offense": 2,
               "conviction_reversed_or_acquittal": 3, "remand_or_new_hearing": 4, "sentence_increased_or_state_relief": 5}
BUCKET_CODE = {"0": 0, "1": 1, "2-4": 2, "5+": 3}


def build() -> pd.DataFrame:
    a = add_scope_flags(pd.read_csv(SRC))
    cand = pd.read_csv(DATA / "media_mention_candidates.csv")
    inc = cand[cand.manual_decision == "include"]
    refs = inc.groupby("case_id").agg(media_ref_count=("term", "size"),
                                      media_ref_coverage=("manual_reason", lambda s: int(s.isin(["A", "C"]).any())),
                                      media_ref_pressure=("manual_reason", lambda s: int((s == "C").any())),
                                      media_ref_reasoning=("in_reasoning", lambda s: int(s.max())))
    tm = pd.read_csv(DATA / "text_measures_497.csv")
    d = a.merge(refs, on="case_id", how="left").merge(tm, on="case_id", how="left")
    rc = ["media_ref_count", "media_ref_coverage", "media_ref_pressure", "media_ref_reasoning"]
    d[rc] = d[rc].fillna(0).astype(int)
    out = pd.DataFrame({
        "case_id": d.case_id,
        "case_number": d.case_number,
        "decision_date": d.decision_date,
        "year": d.year,
        "year_c": d.year - 2015,
        "merits_appeal": d.merits_appeal,
        "non_merits_reason": d.non_merits_reason,
        "homicide_murder": d.homicide_murder,
        "panel_size": d.panel_size,
        "media_any": d.any_district_plus_appeal_media.astype(int),
        "media_count": d.district_plus_appeal_article_count.astype(int),
        "media_bucket": d.district_plus_appeal_article_count.map(salience_bucket).map(BUCKET_CODE),
        "media_log": d.log_district_plus_appeal_attention,
        "media_district_count": d.district_verdict_article_count.fillna(0).astype(int),
        "media_appeal_any": d.any_appeal_stage_media.astype(int),
        "media_appeal_count": d.appeal_stage_article_count.astype(int),
        "media_primo_any": d.primo_newspaper_any_media.astype(int),
        "media_combined_appeal_any": d.combined_google_or_primo_any_media.astype(int),
        "intervention": d.court_intervention.astype(int),
        "defendant_helped": d.defendant_helped.astype(int),
        "outcome_direction": d.defendant_outcome_direction.astype(int),
        "relief_type": d.relief_type.map(RELIEF_CODE),
        "timeline_clean": d.timeline_clean_sample.astype(int),
        "media_ref_any": (d.media_ref_count > 0).astype(int),
        "media_ref_count": d.media_ref_count,
        "media_ref_coverage": d.media_ref_coverage,
        "media_ref_pressure": d.media_ref_pressure,
        "media_ref_reasoning": d.media_ref_reasoning,
        "words": d.n_words,
        "reasoning_method": d.reasoning_method,
        "r_words": d.r_words,
        "r_sentence_len": d.r_sentence_len.round(3),
        "r_sentence_len_p90": d.r_sentence_len_p90.round(3),
        "r_word_len": d.r_word_len.round(3),
        "r_long_words_pct": d.r_long_words_pct.round(3),
        "r_very_long_words_pct": d.r_very_long_words_pct.round(3),
        "r_paren_per_1000": d.r_paren_per_1000.round(3),
    })
    out["media_district_any"] = (out.media_district_count > 0).astype(int)
    out["words_log"] = (out.words.clip(lower=1)).apply(lambda x: __import__("math").log(x)).round(4)
    out["r_words_log"] = (out.r_words.clip(lower=1)).apply(lambda x: __import__("math").log(x)).round(4)
    # appeals concerning attempted murder only (no death mentioned in the judgment); flags come from attempt_only.py
    flags = pd.read_csv(ROOT / "03_ניתוח" / "attempt_only_flags.csv")
    out = out.merge(flags, on="case_id", how="left")
    out["attempt_only"] = out.attempt_only.fillna(0).astype(int)
    # the trial-court window exists only where the district-court decision date was found (446 of 497);
    # the trial-court-only robustness check is run on these cases
    q = pd.read_csv(SRC.parent / "query_log_2010_2020_primo_manual_review.csv", usecols=["case_id", "window_type"])
    dwin = set(q.loc[q.window_type == "district_verdict_stage_media", "case_id"])
    out["media_district_window"] = out.case_id.isin(dwin).astype(int)
    assert out.relief_type.notna().all() and out.media_bucket.notna().all()
    return out


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    df = build()
    df.to_csv(OUT, index=False, encoding="utf-8-sig")
    print(OUT, df.shape)
    print("merits:", int(df.merits_appeal.sum()), "| media_any among merits:", int(df[df.merits_appeal == 1].media_any.sum()))
