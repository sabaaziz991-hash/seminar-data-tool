"""Text measures for the supplementary analyses.

1. Media references in the judgment's reasoning: dictionary flagging + manual verification in context.
2. Readability / textual complexity: length, mean sentence length, mean word length, LIX.

Outputs (02_נתונים):
  main_judgments_497.parquet          - the operative Supreme Court judgment text per case
  media_mention_candidates.csv        - every flagged context, with auto/manual decision columns
  text_measures_497.csv               - one row per case
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "02_נתונים"
STUDY = DATA / "FINAL_STUDY_DATA_2010_2020_PRIMO_MANUAL_REVIEW_2026-05-27_113917" / "01_final_dataset" / "final_analysis_variables_2010_2020_primo_manual_review.csv"
DOCS = DATA / "judgments_497_all_documents.parquet"

PFX = r"(?<![֐-׿A-Za-z])[והבלמשכ]{0,3}"
END = r"(?![֐-׿])"
MEDIA_TERMS = {
    "תקשורת": PFX + r"תקשורת(?:י|ית|יים|יות)?" + END,
    "עיתונות": PFX + r"עיתונ(?:ות|אי|אים|אית|איות|ים|י)?" + END,
    "סיקור": PFX + r"(?:סיקור|מסוקר|מסוקרת|מסוקרים)" + END,
    "כתבות": PFX + r"(?:כתבות|כתבה\s+(?:ב|ש)?(?:עיתון|אתר|טלוויזיה|תקשורת|חדשות))" + END,
    "חדשות": r"(?:(?:מהדורת|מהדורות|אתר|אתרי|כתב|כתבת|כתבי|ערוץ|שידורי|שידור)\s+ה?חדשות|(?<![֐-׿])ו?בחדשות)" + END,
    "טלוויזיה": PFX + r"(?:טלוויזי(?:ה|וני|ונית|וניים))" + END,
    "רדיו": PFX + r"רדיו" + END,
    # media interviews and publications
    "ראיון": PFX + r"(?:ראיון|ריאיון|ראיונות|ריאיונות|התראיין|התראיינה|התראיינו|מתראיין|מתראיינת)" + END,
    "פרסום": PFX + r"(?:פרסום|פרסומים|פרסומי|פורסם|פורסמה|פורסמו|פרסמה|פרסמו)" + END,
}
# Non-media senses of "תקשורת" that are common in homicide judgments (phones, cell sites, interpersonal).
AUTO_EXCLUDE = [
    r"נתוני\s+ה?תקשורת", r"מחקר(?:י)?\s+ה?תקשורת", r"תקשורת\s+(?:סלולרית|טלפונית|אלחוטית|בין|עם|מחשבים|לקויה|בינאישית)",
    r"ב?תקשורת\s+עם", r"פלט(?:י)?\s+ה?תקשורת", r"חבר(?:ת|ות)\s+ה?תקשורת", r"אנטנ(?:ה|ות)", r"מכשיר(?:י)?\s+ה?תקשורת",
    r"קו(?:וי)?\s+ה?תקשורת", r"מערכ(?:ת|ות)\s+ה?תקשורת", r"חוק\s+ה?תקשורת", r"ניתוח\s+ה?תקשורת", r"אמצעי\s+תקשורת\s+(?:אלקטרוני|סלולרי)",
    r"כושר\s+ה?תקשורת", r"יכולת\s+ה?תקשורת", r"תקשורת\s+(?:מילולית|רגשית|תקינה|טובה|קשה)", r"צור(?:ת|ות)\s+ה?תקשורת",
    r"(?:סים|כרטיס)\S*\s+תקשורת", r"תקשורת\s+נתונים",
    r"מכשיר(?:י)?\s+(?:ה)?(?:טלוויזיה|רדיו|קשר)", r"(?:צפה|צפו|צופה|צפתה|צפייה|צפיה|צופים)\s+ב?(?:ה)?טלוויזיה", r"מסך\s+ה?טלוויזיה",
    r"טלוויזי\S*\s+(?:ב)?מעגל\s+סגור", r"(?:ה)?טלוויזיה\s+ב(?:חדר|סלון)", r"קשר\s+(?:ה)?רדיו", r"רדיו\s+(?:ה)?משטרתי", r"(?:ב|ה)?רדיו\s+(?:ב|של\s+)?(?:ה)?רכב",
    # legal senses of "פרסום": gag orders, publication of rulings/laws, citation formulas
    r"איסור\s+(?:ה)?פרסום", r"צו\s+(?:ה)?איסור", r"(?:לא|טרם)\s+(?:ה)?(?:פורסם|פורסמ\S*)", r"(?:פורסם|פורסמ\S*)\s+ב(?:נבו|מאגר|מאגרים|פדאור|תקדין|דינים|רשומות|ילקוט|אתר)",
    r"(?:מותר|אסור|הותר)\S*\s+(?:ב|ל)?פרסום", r"פרסום\s+(?:פסק|גזר|החלטה|הכרעת|ה?תקנות|ה?חוק|שמו?ת?|פרטי\S*\s+מזה)",
    r"ברשומות", r"פרסום\s+(?:ה)?(?:ראיות|חומר\s+ה?חקירה)", r"פרסום\s+(?:ה)?(?:דיבה|לשון\s+הרע)",
    r"ראיון\s+(?:ה)?(?:משטרתי|במשטרה|עבודה|קבלה|פסיכיאטרי|קליני)", r"ראיונות?\s+(?:עם\s+)?(?:ה)?(?:פסיכיאטר|פסיכולוג|עובדת\s+סוציאלית|קצינת\s+מבחן|שירות\s+המבחן)",
]


def clean_text(t: str) -> str:
    t = re.sub(r"<!--.*?-->", " ", t or "", flags=re.S)
    t = re.sub(r"\{[^{}]{0,600}\}", " ", t)
    t = re.sub(r"<[^>]{0,200}>", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def body_of(t: str) -> str:
    """Strip the caption (court, panel, parties, lawyers) and the signature footer."""
    start = t.find("בבית המשפט העליון")
    t = t[start:] if start >= 0 else t
    lawyers = t.find("בשם ה")
    m = re.search(r"פסק[-\s]?דין", t[lawyers:] if lawyers >= 0 else t)
    if m:
        t = t[(lawyers if lawyers >= 0 else 0) + m.end():]
    end = t.rfind("ניתן היום")
    if end > 0:
        t = t[:end]
    return t.strip()


def select_main_documents(study: pd.DataFrame, docs: pd.DataFrame) -> pd.DataFrame:
    docs = docs[docs.text.notna()].copy()
    docs["vd"] = pd.to_datetime(docs.VerdictDt).dt.tz_localize(None)
    rows = []
    for _, r in study.iterrows():
        x = docs[(docs.study_case_id == r.case_id) & (docs.Type == "פסק-דין")].copy()
        x["dd"] = (x.vd - pd.Timestamp(r.decision_date)).abs()
        m = x.sort_values(["Technical", "dd"]).iloc[0]
        full = clean_text(m.text)
        rows.append({"case_id": r.case_id, "case_number": r.case_number, "document_hash": m.document_hash,
                     "doc_verdict_date": m.vd.date().isoformat(), "full_text": full, "body_text": body_of(full)})
    return pd.DataFrame(rows)


def media_candidates(main: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, r in main.iterrows():
        t = r.body_text
        for term, pat in MEDIA_TERMS.items():
            for m in re.finditer(pat, t):
                s, e = max(0, m.start() - 160), min(len(t), m.end() + 160)
                ctx = t[s:e]
                local = t[max(0, m.start() - 40): m.end() + 40]
                auto_ex = any(re.search(p, local) for p in AUTO_EXCLUDE)
                rows.append({"case_id": r.case_id, "case_number": r.case_number, "term": term,
                             "match": m.group(0), "position": m.start(), "auto_excluded": int(auto_ex),
                             "context": ctx})
    return pd.DataFrame(rows)


HEB_WORD = re.compile(r"[א-תA-Za-z]+(?:[\"'׳״][א-ת]+)?")


REASONING_MARKERS = [
    ("heading_discussion_decision", r"(?:ה)?דיון\s+ו(?:ה)?הכרעה"),
    ("heading_discussion_numbered", r"\d+\.\s*דיון(?![א-ת])|(?<![א-ת])דיון(?![א-ת])\s+\d+\."),
    ("court_turn_phrase", r"לאחר\s+ש(?:עיינתי|עיינו|שקלתי|שקלנו|בחנתי|בחנו)"),
]


def reasoning_start(body: str) -> tuple[int, str]:
    """Offset where the court's own discussion begins ('דיון והכרעה' heading and fallbacks).
    Markers in the first 5% of the text are ignored (they tend to be summaries, not headings)."""
    floor = int(len(body) * 0.05)
    for name, pat in REASONING_MARKERS:
        for m in re.finditer(pat, body):
            if m.start() >= floor:
                return m.start(), name
    return 0, "whole_judgment"


def sentence_lengths(t: str) -> list[int]:
    # sentence boundaries: . ! ? : ; followed by space, but not paragraph numbers like "12. "
    parts = re.split(r"(?<!\b\d)(?<!\b\d\d)[.!?;:](?=\s)", t)
    return [len(HEB_WORD.findall(s)) for s in parts if HEB_WORD.search(s)]


def complexity(t: str) -> dict[str, float]:
    """The six components of the textual-complexity index."""
    words = HEB_WORD.findall(t)
    n = len(words)
    lens = sentence_lengths(t) or [n]
    letters = [len(re.sub(r"[\"'׳״]", "", w)) for w in words]
    s = pd.Series(lens, dtype=float)
    return {
        "r_words": n,
        "r_sentences": len(lens),
        "r_sentence_len": float(s.mean()),
        "r_sentence_len_p90": float(s.quantile(0.9)),
        "r_word_len": sum(letters) / n if n else float("nan"),
        "r_long_words_pct": 100 * sum(L > 6 for L in letters) / n if n else float("nan"),
        "r_very_long_words_pct": 100 * sum(L > 8 for L in letters) / n if n else float("nan"),
        "r_paren_per_1000": 1000 * t.count("(") / n if n else float("nan"),
    }


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    study = pd.read_csv(STUDY)
    docs = pd.read_parquet(DOCS)
    main_docs = select_main_documents(study, docs)
    starts = main_docs.body_text.map(reasoning_start)
    main_docs["reasoning_start"] = starts.map(lambda x: x[0])
    main_docs["reasoning_method"] = starts.map(lambda x: x[1])
    main_docs.to_parquet(DATA / "main_judgments_497.parquet", index=False)
    cand = media_candidates(main_docs)
    rs = main_docs.set_index("case_id").reasoning_start
    cand["in_reasoning"] = (cand.position >= cand.case_id.map(rs)).astype(int)
    # manual decisions are stored by a stable key (case_id, position, term) in 03_ניתוח/media_manual_decisions.csv
    keyed = ROOT / "03_ניתוח" / "media_manual_decisions.csv"
    if keyed.exists():
        keep = pd.read_csv(keyed)[["case_id", "position", "term", "manual_decision", "manual_reason"]]
        cand = cand.merge(keep, on=["case_id", "position", "term"], how="left")
    else:
        cand["manual_decision"] = ""
        cand["manual_reason"] = ""
    cand.to_csv(DATA / "media_mention_candidates.csv", index=False, encoding="utf-8-sig")
    rows = []
    for _, r in main_docs.iterrows():
        body = r.body_text
        rows.append({"case_id": r.case_id, "n_words": len(HEB_WORD.findall(body)), "reasoning_method": r.reasoning_method,
                     **complexity(body[r.reasoning_start:])})
    meas = pd.DataFrame(rows)
    meas.to_csv(DATA / "text_measures_497.csv", index=False, encoding="utf-8-sig")
    print("reasoning extraction:", meas.reasoning_method.value_counts().to_dict())
    pending = cand[(cand.auto_excluded == 0) & cand.manual_decision.isna()]
    print("candidates needing manual review:", len(pending))
    print("main docs:", len(main_docs), "| candidates:", len(cand), "| auto-excluded:", int(cand.auto_excluded.sum()),
          "| cases with any non-excluded candidate:", cand[cand.auto_excluded == 0].case_id.nunique())
    print(cand[cand.auto_excluded == 0].term.value_counts().to_dict())


if __name__ == "__main__":
    main()
