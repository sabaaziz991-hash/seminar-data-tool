"""Flags appeals that concern attempted murder only: no one died in the offence.

The offence category "רצח" in the study includes attempted murder (סעיף 305 לחוק העונשין). For the
sensitivity check that drops these appeals, a case is flagged when the judgment's body text mentions
attempted murder and contains none of the expressions that indicate a death. Cases the rule cannot
decide correctly are listed in MANUAL with the reason, after reading the judgment.

Output: 03_ניתוח/attempt_only_flags.csv (case_id, attempt_only), merged by build_dataset.py.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

ATTEMPT = re.compile(r"ניסיון (?:ל)?רצח|ניסיון לרצוח|לנסות לרצוח")
# whole words only (an optional one- or two-letter prefix such as ו/ש/ה/ב/ל/מ/כ is allowed), so that
# "הלימותו של" or "התרשמותו של" are not read as "מותו של"
DEATH = re.compile(r"(?<![א-ת])[ובהלמשכ]{0,2}(?:"
                   r"המנוח|המנוחה|המנוחים|המנוחות|נרצח|נרצחה|נרצחו|נהרג|נהרגה|נהרגו|קיפח את חייו|קיפחה את חייה|"
                   r"גרם למותו|גרם למותה|גרם למותם|מותו של|מותה של|מותם של|הרוג|הקורבן שנפטר|נפטר|נפטרה|"
                   r"גופת|גופתו|גופתה|המתה)")

# case_number -> (attempt_only, reason), decided by reading the judgment
MANUAL: dict[str, tuple[int, str]] = {}


def flags() -> pd.DataFrame:
    mj = pd.read_parquet(ROOT / "02_נתונים" / "main_judgments_497.parquet")
    text = mj.body_text.fillna("")
    out = pd.DataFrame({
        "case_id": mj.case_id,
        "case_number": mj.case_number,
        "attempt_only": [int(bool(ATTEMPT.search(t)) and not DEATH.search(t)) for t in text],
    })
    for num, (val, _reason) in MANUAL.items():
        out.loc[out.case_number == num, "attempt_only"] = val
    return out


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    f = flags()
    f[["case_id", "attempt_only"]].to_csv(ROOT / "03_ניתוח" / "attempt_only_flags.csv", index=False)
    print("attempt-only appeals:", int(f.attempt_only.sum()), "of", len(f))
