# Appeals Media Study Codebook

## Reproducibility Metadata

- dataset_source: huggingface_first_live_fallback
- hugging_face_dataset_name: LevMuchnik/SupremeCourtOfIsrael
- classification_rules_version: rules_v2
- generated_at: 2026-05-27T11:39:17

## Variables

- `murder_or_homicide`: 1 when rules identify murder, attempted murder, manslaughter, reckless homicide, or causing death; 0 otherwise.
- `defendant_outcome_direction`: Signed Supreme Court effect relative to the defendant: -1 worse for defendant, such as State appeal accepted or sentence increased; 0 no relief/no change; 1 favorable relief; blank when unclear.
- `defendant_favorable_outcome`: Binary convenience variable: 1 when the Supreme Court result improves the defendant position; 0 when there is no defendant relief or the result is adverse; blank when unclear.
- `appeal_outcome_normalized`: -1 defendant position worsened; 0 no defendant relief/no change; 1 sentence relief only; 2 lesser offense; 3 reversal/acquittal; 4 remand/new hearing; 5 mixed/unclear.
- `relief_type`: Text label for the kind of defendant relief, adverse State relief, sentence increase, or mixed/unclear result.
- `media_attention_count`: Alias of included_article_count: curated unique pre-decision articles included for the case.
- `log_media_attention`: Natural log of 1 + included_article_count.
- `crime_stage_article_count`: Included articles in the offense-event stage window when an offense date is available.
- `district_verdict_article_count`: Included articles around the District Court verdict/sentence window, default district date -7 through +30 days.
- `baseline_salience_count`: crime_stage_article_count + district_verdict_article_count; intended as pre-Supreme-Court baseline public salience.
- `log_baseline_salience`: Natural log of 1 + baseline_salience_count.
- `appeal_stage_article_count`: Included articles in the Supreme Court appeal-stage pre-decision window.
- `case_development_article_count`: Included articles tagged as later case-development review material, such as new evidence or retrial narratives, when available.
- `any_baseline_media`: 1 when baseline_salience_count is greater than zero; 0 otherwise.
- `baseline_media_bucket`: Bucketed baseline salience: none, one, low, medium, or high.
- `district_verdict_date`: Extracted lower-court verdict/sentence date used to build district_verdict_stage_media.
- `offense_date`: Extracted underlying offense date when available; lower confidence by default.
- `timeline_needs_review`: 1 when the rule-based timeline extractor could not confidently reconstruct the lower-court/offense timeline: no District Court verdict/sentence date was found, the District Court date confidence is below 0.8, or an extracted offense date is present but low-confidence. This flag is a timeline-quality flag, not an exclusion flag; final analyses should report a sensitivity check excluding flagged cases.
- `primo_newspaper_raw_article_count`: Raw Primo/Summon authenticated Advanced Search API rows stored for the appeal-stage pre-decision query window. The current preferred Primo source uses one case-specific query per case: person name plus offense anchor plus exact date-window clauses.
- `primo_newspaper_article_count`: Deduplicated included Primo/Summon authenticated Advanced Search API records inside the appeal-stage pre-decision window after strict local date filtering, likely news/press source filtering, and visible case-context filtering. Hidden-field-only matches are stored for manual review and not counted automatically. Treated as a robustness/source-coverage measure, not the primary article-count salience variable.
- `primo_newspaper_any_media`: 1 when `primo_newspaper_article_count` is greater than zero; 0 otherwise.
- `primo_newspaper_unique_source_count`: Number of distinct newspaper/source titles among included Primo/Summon records.
- `combined_google_or_primo_any_media`: 1 when either curated Google News media or Primo/Summon newspaper records are present in the appeal-stage pre-decision window.
- `media_window_start`: Start of the appeal-stage pre-decision media window.
- `media_window_end`: Day before Supreme Court decision; post-decision media is not generated for this study.

## Design Warnings

- For causal interpretation, use only pre-decision media attention.
- רע"פ is an application for leave to appeal, not the same as an appeal as of right.
- If the State is the appellant, appeal accepted is coded as not defendant-favorable; clear sentence increases are coded as `sentence_increased_or_state_relief`.
